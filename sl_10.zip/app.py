from flask import (
	Flask,
	request,
	render_template,
	redirect,
	url_for,
	jsonify
)

from pymongo import MongoClient
import requests
from datetime import datetime

app = Flask(__name__)

password = 'sparta'
client = MongoClient(f'mongodb://ditiya:{password}@ac-rcamlhi-shard-00-00.rc6xlci.mongodb.net:27017,ac-rcamlhi-shard-00-01.rc6xlci.mongodb.net:27017,ac-rcamlhi-shard-00-02.rc6xlci.mongodb.net:27017/?ssl=true&replicaSet=atlas-7keaa1-shard-0&authSource=admin&retryWrites=true&w=majority')
db = client.dbsparta_plus_week2

@app.route('/')
def main():
	words_result = db.words.find({}, {'_id': False})
	words = []
	for word in words_result:
		definition = word['definitions'][0]['shortdef']
		definition = definition if type(definition) is str else definition[0]
		words.append({
			'word': word['word'],
			'definition': definition,
		})

	msg = request.args.get('msg')

	return render_template(
		'index.html',
		words=words
		)

@app.route('/detail/<keyword>')
def detail(keyword):
	api_key = 'a8375614-d092-479f-9667-18a09f28da29'
	url = f'https://www.dictionaryapi.com/api/v3/references/collegiate/json/{keyword}?key={api_key}'
	response = requests.get(url)
	definitions = response.json()

	if not definitions:
		return redirect(url_for(
			'error',
			msg=f'Could not find "{keyword}"'
    ))

	if type(definitions[0]) is str:
		suggests= []
		for sugest in definitions:
			suggests.append(sugest)
		return redirect(url_for(
			'error',
			msg=f'Could not find "{keyword}"',
			suggests = "%".join(suggests),
			))
	return render_template('detail.html', word=keyword, definitions=definitions, status=request.args.get('status_give', 'new'))

@app.route('/error')
def error():
	msg = request.args.get('msg')
	suggests_list = request.args.get('suggests')
	suggests = []
	if suggests_list:
		suggests = suggests_list.split('%')
	
	return render_template(
		'error.html',
		msg=msg,
		suggests = suggests,
		)

@app.route('/api/save_word', methods=['POST'])
def save_word():
    #  This handler should save the word in the database
    json_data = request.get_json()
    word = json_data.get('word_give')
    definitions = json_data.get('definitions_give')
    doc = {
    	'word': word,
        'definitions': definitions,
    	'date': datetime.now().strftime('%Y%m%d'),
    }
    db.words.insert_one(doc)
    return jsonify({
    	'result': 'success',
    	'msg': f'the word, {word}, wwas saved!!!'
    })


@app.route('/api/delete_word', methods=['POST'])
def delete_word():
    #  This handler should delete the word from the database
    word = request.form.get('word_give')
    db.words.delete_one({'word': word})
    return jsonify({
    	'result': 'success',
        'msg': f'the word {word} was deleted'
    })

if __name__ =='__main__':
	app.run('0.0.0.0', port=5000, debug=True)